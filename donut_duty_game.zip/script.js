const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 800;
canvas.height = 600;

let officer = {
    x: 150,
    y: 400,
    radius: 20,
    vx: 0,
    vy: 0,
    isDragging: false,
    launched: false
};

const donut = {
    x: 600,
    y: 300,
    radius: 60,
    holeRadius: 25
};

function drawOfficer() {
    ctx.beginPath();
    ctx.fillStyle = "blue";
    ctx.arc(officer.x, officer.y, officer.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
}

function drawDonut() {
    ctx.beginPath();
    ctx.fillStyle = "pink";
    ctx.arc(donut.x, donut.y, donut.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.fillStyle = "#eef";
    ctx.arc(donut.x, donut.y, donut.holeRadius, 0, Math.PI * 2);
    ctx.fill();
}

function update() {
    if (officer.launched) {
        officer.vy += 0.5; // gravity
        officer.x += officer.vx;
        officer.y += officer.vy;
    }
    checkCollision();
}

function checkCollision() {
    const dx = officer.x - donut.x;
    const dy = officer.y - donut.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    if (distance > donut.holeRadius && distance < donut.radius) {
        console.log("Missed the hole!");
    } else if (distance <= donut.holeRadius) {
        console.log("Scored!");
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawDonut();
    drawOfficer();
    if (officer.isDragging) {
        ctx.beginPath();
        ctx.moveTo(150, 400);
        ctx.lineTo(officer.x, officer.y);
        ctx.stroke();
    }
}

function gameLoop() {
    update();
    draw();
    requestAnimationFrame(gameLoop);
}

canvas.addEventListener("touchstart", startDrag, false);
canvas.addEventListener("touchmove", onDrag, false);
canvas.addEventListener("touchend", endDrag, false);
canvas.addEventListener("mousedown", startDrag, false);
canvas.addEventListener("mousemove", onDrag, false);
canvas.addEventListener("mouseup", endDrag, false);

function getEventPos(e) {
    if (e.touches) {
        return { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
    return { x: e.clientX, y: e.clientY };
}

function startDrag(e) {
    const pos = getEventPos(e);
    const dx = pos.x - officer.x;
    const dy = pos.y - officer.y;
    if (Math.sqrt(dx * dx + dy * dy) < officer.radius) {
        officer.isDragging = true;
        officer.launched = false;
    }
}

function onDrag(e) {
    if (officer.isDragging) {
        const pos = getEventPos(e);
        officer.x = pos.x;
        officer.y = pos.y;
    }
}

function endDrag(e) {
    if (officer.isDragging) {
        officer.isDragging = false;
        officer.vx = (150 - officer.x) / 10;
        officer.vy = (400 - officer.y) / 10;
        officer.launched = true;
    }
}

gameLoop();
